
# VisionGuide

Multimodal AI Accessibility Agent.

## Run

pip install fastapi uvicorn pillow

uvicorn api.main:app --reload

Open:

http://localhost:8000
