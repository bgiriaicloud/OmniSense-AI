
def analyze_image(image):
    return {
        "scene": "hallway",
        "hazard": "stairs",
        "guidance": "walk carefully"
    }
