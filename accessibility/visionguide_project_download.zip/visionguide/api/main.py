
from fastapi import FastAPI, UploadFile
from PIL import Image
import io

app = FastAPI()

@app.get("/")
def root():
    return {"message": "VisionGuide API running"}

@app.post("/analyze_scene")
async def analyze_scene(file: UploadFile):
    contents = await file.read()
    image = Image.open(io.BytesIO(contents))
    return {
        "scene": "Example: hallway detected",
        "hazard": "Example: stairs ahead",
        "guidance": "Use handrail on the right"
    }
